mutable struct SMKPData

    # Sets
    I   # items
    J   # xz-knapsacks
    K   # xy-knapsacks
    Pr  # scenarios

    # Parameters
    A
    E
    T
    W
    b
    h
    c
    d
    q

    SMKPData() = new()
end
