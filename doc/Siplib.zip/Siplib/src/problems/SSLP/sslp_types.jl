mutable struct SSLPData

    # Sets
    J
    I
    S
    Z

    # Parameters
    c
    q
    q0
    d
    u
    v
    w
    Jz
    h
    Pr

    SSLPData() = new()
end
